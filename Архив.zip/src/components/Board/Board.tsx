import { useEffect, useState } from 'react'
import { fetchData } from '../../api/api'
import { FETCH_URL, LIST_NAME } from '../../config'
import { TCoursesData } from '../../types/types'
import BoardCourses from '../BoardCourses/BoardCourses'
import ListCourses from '../ListCourses/ListCourses'

const Board = () => {
  const [dataCourse, setDataCourse] = useState<TCoursesData[]>([]) // Храним курсы
  const [listItem, setListItem] = useState() // Храним категорию курса
  const [loading, setLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  
  const loadData = async () => {
        setLoading(true)
        setError(null)

        try {
            const data = await fetchData(FETCH_URL)
            if (data) {
                setDataCourse(data)
            }
        } catch (error) {
            setError('Не удалось загрузить данные. Попробуйте еще раз позже.');
            console.error('Network response was not ok', error)
            throw error
        } finally {
            setLoading(false); 
        }
    };

  // Получаем все курсы 
  useEffect(() => {
        loadData();
    }, []);

  if (loading) {
      return <div className="loading">Загрузка...</div>;
  }
  
  return (
    <div className='container'>
        <div className="board">
            <ListCourses />
            <BoardCourses dataCourse={dataCourse} />
        </div>
    </div>
  )
}

export default Board